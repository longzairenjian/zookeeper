package com.lagou.dubbo;

import com.lagou.dubbo.service.HelloServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Slf4j
public class ConsumerMainTest {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ConsumerConfiguration.class);
        context.start();
        HelloServiceImpl helloService = context.getBean(HelloServiceImpl.class);

        ThreadPoolExecutor executor = new ThreadPoolExecutor(500, 500, 20, TimeUnit.SECONDS, new LinkedBlockingQueue<>());
        long start = System.currentTimeMillis();
        long expectEnd = start + 60 * 1000;
        int count = 0;
        for (int i = 0; i < 2000 ; i++) {
            executor.execute(() -> {
               helloService.methodA();
               helloService.methodB();
               helloService.methodC();
            });

            count ++;

            if (System.currentTimeMillis() > expectEnd) {
                expectEnd += 60*1000;
                log.info("--------- 一分钟内执行的任务次数为: {}-------", count);
            }

            try {
                TimeUnit.MILLISECONDS.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

    }

    @Configuration
    @PropertySource("classpath:/dubbo-consumer.properties")
    //@EnableDubbo(scanBasePackages = "com.lagou.bean")
    @ComponentScan("com.lagou.dubbo")
    @EnableDubbo
    static class ConsumerConfiguration {

    }
}
