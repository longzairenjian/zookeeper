package com.lagou.dubbo.service;

import com.lagou.dubbo.HelloServiceI;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Service;

@Service
public class HelloServiceImpl implements HelloServiceI {

    @Reference
    private HelloServiceI helloService;

    @Override
    public String sayHello(String name, Integer waitTime) {
        return helloService.sayHello(name, waitTime);
    }

    @Override
    public void methodA() {
        helloService.methodA();
    }

    @Override
    public void methodB() {
        helloService.methodB();
    }

    @Override
    public void methodC() {
        helloService.methodC();
    }
}
