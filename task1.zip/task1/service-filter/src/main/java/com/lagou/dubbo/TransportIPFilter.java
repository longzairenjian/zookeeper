package com.lagou.dubbo;

import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;


@Activate(group = {CommonConstants.PROVIDER})
public class TransportIPFilter implements Filter {

    Logger log = LoggerFactory.getLogger(TransportIPFilter.class);

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        try {
            return invoker.invoke(invocation);
        } finally {
            InetSocketAddress remoteAddress = RpcContext.getContext().getRemoteAddress();
            log.info("remote invoke address is : {}", remoteAddress.getHostString().toString());
        }
    }
}
