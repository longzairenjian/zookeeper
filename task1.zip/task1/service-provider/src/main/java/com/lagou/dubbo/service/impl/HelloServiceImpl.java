package com.lagou.dubbo.service.impl;

import com.lagou.dubbo.HelloServiceI;
import lombok.extern.slf4j.Slf4j;
import org.apache.dubbo.config.annotation.Service;

import java.util.concurrent.TimeUnit;

@Slf4j
@Service
public class HelloServiceImpl implements HelloServiceI {
    @Override
    public String sayHello(String name, Integer waitTime) {
        return "hello, " + name;
    }

    @Override
    public void methodA() {
        printFunc("methodA");
    }

    @Override
    public void methodB() {
        printFunc("methodB");
    }

    @Override
    public void methodC() {
        printFunc("methodC");
    }

    private void printFunc (String methodName) {
        sleep();
        log.info("{} is invoked.", methodName);
    }

    private void sleep() {
        try {
            int time = (int)(Math.random() * 1000);
            TimeUnit.MILLISECONDS.sleep(time);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
