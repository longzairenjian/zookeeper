package com.lagou.dubbo;

public interface HelloServiceI {

    String sayHello(String name, Integer waitTime) ;

    void methodA ();

    void methodB ();

    void methodC ();
}
