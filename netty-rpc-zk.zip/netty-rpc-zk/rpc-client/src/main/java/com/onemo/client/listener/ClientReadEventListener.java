package com.onemo.client.listener;

import com.onemo.client.core.Client;
import com.onemo.client.core.ClientTask;
import com.onemo.client.core.ClientTaskHelper;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;

public class ClientReadEventListener implements ApplicationListener<ApplicationReadyEvent> {

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        ClientTask clientTask = ClientTaskHelper.getClientTask();
        System.out.println("netty client 已经启动了");
    }
}
