package com.onemo.client.route;

import com.onemo.client.core.Client;

public interface SendMsgService {

    void routeSendMsg(String cmd, Object msg);

    void sendAll(String cmd, Object msg);

    void sendMsg(Client client, String cmd, Object msg);
}
