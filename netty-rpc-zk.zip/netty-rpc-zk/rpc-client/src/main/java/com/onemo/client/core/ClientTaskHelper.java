package com.onemo.client.core;

import com.onemo.common.util.ThreadUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ThreadPoolExecutor;

public class ClientTaskHelper {
    private static final Map<String, ClientTask> clientTaskMap = new HashMap<>();
    private static final String DEFAULT_HOST = "127.0.0.1";
    private static final int DEFAULT_PORT = 8888;

    private static final ThreadPoolExecutor threadPoolExecutor = ThreadUtil.createThreadPool();

    public static Map<String, ClientTask> getClientTaskMap() {
        return clientTaskMap;
    }


    public static ClientTask get(String ip) {
        return clientTaskMap.get(ip);
    }

    public static ClientTask getClientTask() {
        return getClientTask(DEFAULT_HOST, DEFAULT_PORT);
    }

    public static ClientTask getClientTask(String host, int port) {
        String key = getKey(host, port);
        ClientTask clientTask = clientTaskMap.get(key);
        if (Objects.isNull(clientTask)) {
            Client client = Client.getInstance(host, port);
            clientTask = new ClientTask(client);
            threadPoolExecutor.execute(clientTask);
            clientTaskMap.put(key, clientTask);
        }
        return clientTask;
    }


    public static void initClient(String host, int port) {
        getClientTask(host, port);
    }

    public static void removeClient(String host, int port) {
        Client.remove(host, port);
        clientTaskMap.remove(getKey(host, port));
    }


    public static String getKey(String host, int port) {
        return host + ":" + port;
    }

}
