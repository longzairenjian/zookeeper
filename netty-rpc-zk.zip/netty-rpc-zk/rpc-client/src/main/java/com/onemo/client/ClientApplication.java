package com.onemo.client;

import com.onemo.client.listener.ClientReadEventListener;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.onemo")
@SpringBootApplication
public class ClientApplication {

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(ClientApplication.class);
        application.addListeners(new ClientReadEventListener());
        application.run(args);
    }
}
