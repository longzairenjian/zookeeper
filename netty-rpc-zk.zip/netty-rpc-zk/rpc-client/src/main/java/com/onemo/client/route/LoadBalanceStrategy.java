package com.onemo.client.route;


public interface LoadBalanceStrategy {

    /**
     * 路由到响应时间最短的服务器
     * @return 路由到的服务器ip
     */
    String route();
}
