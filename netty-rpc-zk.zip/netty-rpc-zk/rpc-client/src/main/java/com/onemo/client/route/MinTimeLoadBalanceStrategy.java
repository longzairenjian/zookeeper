package com.onemo.client.route;

import org.springframework.stereotype.Service;


@Service
public class MinTimeLoadBalanceStrategy implements LoadBalanceStrategy {


    @Override
    public String route() {
        return RouteHandler.getMin();
    }
}
