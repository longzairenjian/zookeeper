package com.onemo.client.core;

public class Metrics {

    private String host;

    private int port;

    private long startTime;

    private long cost;


    public Metrics(String host, int port) {
        this.host = host;
        this.port = port;
        this.startTime = System.currentTimeMillis();
    }


    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getCost() {
        return cost;
    }

    public void setCost(long cost) {
        this.cost = cost;
    }
}
