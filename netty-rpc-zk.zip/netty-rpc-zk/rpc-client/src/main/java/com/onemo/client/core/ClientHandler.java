package com.onemo.client.core;

import com.alibaba.fastjson.JSONObject;
import com.onemo.client.route.RouteHandler;
import com.onemo.common.Message;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;

public class ClientHandler extends ChannelInboundHandlerAdapter implements Callable<Message> {

    private ChannelHandlerContext context;
    private Message result;
    private Message param;

    private final AtomicBoolean callable = new AtomicBoolean(false);

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        this.context = ctx;

    }

    @Override
    public synchronized void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        if (callable.get()) {
            result = (Message) msg;
            notify();
        }
        Message message = (Message) msg;
        Object object = message.getBody();
        if (object instanceof JSONObject) {
            JSONObject jsonObject = (JSONObject) object;
            Metrics metrics = JSONObject.parseObject(JSONObject.toJSONString(jsonObject.get("metrics")), Metrics.class);
            if (Objects.nonNull(metrics)) {
                RouteHandler.add(metrics.getHost() + ":" + metrics.getPort(), System.currentTimeMillis() - metrics.getStartTime());
            }
        }
    }

    @Override
    public synchronized Message call() throws Exception {
        if (callable.get()) {
            this.context.writeAndFlush(param);
            wait();
            return result;
        }
        return null;
    }

    public void setParam(Message param) {
        this.param = param;
        callable.set(true);
    }
}
