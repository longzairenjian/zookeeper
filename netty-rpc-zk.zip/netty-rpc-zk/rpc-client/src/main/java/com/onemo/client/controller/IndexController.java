package com.onemo.client.controller;

import com.onemo.client.core.ClientTaskHelper;
import com.onemo.client.route.SendMsgService;
import com.onemo.common.Message;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class IndexController {


    @Resource
    private SendMsgService sendMsgService;

    @GetMapping("/")
    public String index() {
        return "<h1>HELLO NETTY</h1>";
    }


    @GetMapping("sendMsg")
    public void sendMsg(@RequestParam String cmd, String body) {
        sendMsgService.sendMsg(ClientTaskHelper.getClientTask().getClient(), cmd, body);
    }

    @GetMapping("routeSend")
    public void routeSend(@RequestParam String cmd, String body) {
        sendMsgService.routeSendMsg(cmd, body);
    }

    @GetMapping("sendAll")
    public void sendMsgTime(@RequestParam String cmd, String body) {
        sendMsgService.sendAll(cmd, body);
    }

    @GetMapping("sendMsgSync")
    public Object sendMsgSync(@RequestParam String cmd, String body) throws Exception {
        Message message = ClientTaskHelper.getClientTask().sendMessageSync(cmd, body);
        return message.getBody();
    }


}
