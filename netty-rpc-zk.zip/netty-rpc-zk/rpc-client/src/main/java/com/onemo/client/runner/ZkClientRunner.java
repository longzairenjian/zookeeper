package com.onemo.client.runner;

import com.onemo.client.core.Client;
import com.onemo.client.core.ClientTask;
import com.onemo.client.core.ClientTaskHelper;
import com.onemo.common.zk.ProviderConstant;
import com.onemo.common.zk.ZkTemplate;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;

@Component
public class ZkClientRunner implements ApplicationRunner {

    @Resource
    private ZkTemplate zkTemplate;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        //获取服务注册的列表
        List<String> children = zkTemplate.getChildren(ProviderConstant.PROVIDER_PATH);
        System.out.println(children);
        if (CollectionUtils.isEmpty(children)) {
            return;
        }
        //编程题一 第二点 循环服务端列表 跟所有的服务端建立连接
        children.forEach(this::initConnect);

        //编程题一:第三点,第四点 监听ProviderConstant.PROVIDER_PATH服务端路径 如果服务端下线或则上线则需要断开连接或重新建立连接
        zkTemplate.watch(ProviderConstant.PROVIDER_PATH, (curatorFramework, pathChildrenCacheEvent) -> {
            ChildData childData = pathChildrenCacheEvent.getData();
            if (PathChildrenCacheEvent.Type.CHILD_ADDED.equals(pathChildrenCacheEvent.getType())) {
                //新增节点
                initConnect(childData.getPath());
                System.out.println("新增节点成功:" + childData.getPath());
            } else if (PathChildrenCacheEvent.Type.CHILD_REMOVED.equals(pathChildrenCacheEvent.getType())) {
                //移除节点
                removeConnect(childData.getPath());
                System.out.println("移除节点成功:" + childData.getPath());
            }
        });
    }


    private void initConnect(String connect) {
        String[] ipInfo = getIpInfo(connect);
        ClientTaskHelper.initClient(ipInfo[0], Integer.parseInt(ipInfo[1]));
    }


    private void removeConnect(String connect) {
        String[] ipInfo = getIpInfo(connect);
        ClientTaskHelper.removeClient(ipInfo[0], Integer.parseInt(ipInfo[1]));
    }


    private static String[] getIpInfo(String connect) {
        String ipInfo = connect.substring(connect.lastIndexOf("/") + 1);
        return ipInfo.split(":");
    }
}
