package com.onemo.client.core;

import com.onemo.common.Message;
import java.util.concurrent.ExecutionException;

public class ClientTask implements Runnable {

    private final Client client;

    public ClientTask(Client client) {
        this.client = client;
    }

    @Override
    public void run() {
        client.init();
    }


    public Client getClient() {
        return client;
    }

    public void sendMessage(String cmd, Object object) {
        //记录时间

        this.client.sendMessage(cmd, object);
    }

    public Message sendMessageSync(String cmd, Object object) throws ExecutionException, InterruptedException {
        return this.client.sendMessageSync(cmd, object);
    }
}
