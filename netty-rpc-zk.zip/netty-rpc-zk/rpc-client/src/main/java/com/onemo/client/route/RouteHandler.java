package com.onemo.client.route;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public class RouteHandler {

    private static final Map<String, Long> routeMap = new HashMap<>();

    public static void add(String ip, Long timeOut) {
        routeMap.put(ip, timeOut);
    }


    public static String getMin() {
        Set<Map.Entry<String, Long>> entries = routeMap.entrySet();
        Long min = null;
        String minIp = null;
        for (Map.Entry<String, Long> entry : entries) {
            if (Objects.isNull(min)) {
                min = entry.getValue();
            }
            if (Objects.isNull(minIp)) {
                minIp = entry.getKey();
            }
            if (min > entry.getValue()) {
                min = entry.getValue();
                minIp = entry.getKey();
            }
        }
        return minIp;
    }
}
