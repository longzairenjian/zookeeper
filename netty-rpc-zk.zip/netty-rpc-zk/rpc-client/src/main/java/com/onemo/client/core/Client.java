package com.onemo.client.core;

import com.onemo.common.Message;
import com.onemo.common.build.MessageBuilder;
import com.onemo.common.enumtype.MessageType;
import com.onemo.common.serialize.JSONSerializer;
import com.onemo.common.serialize.RpcDecoder;
import com.onemo.common.serialize.RpcEncoder;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class Client {
    private static final ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());


    private static final Map<String, Client> clientMap = new HashMap<>();


    private final String host;
    private final int port;

    public Client(String host, int port) {
        this.host = host;
        this.port = port;
    }

    private Channel channel;

    private ClientHandler clientHandler;

    private final AtomicBoolean isConnect = new AtomicBoolean(false);


    public static void remove(String host, int port) {
        clientMap.remove(ClientTaskHelper.getKey(host, port));
    }


    public static Client getInstance(String host, int port) {
        String key = ClientTaskHelper.getKey(host, port);
        Client client = clientMap.get(key);
        if (Objects.isNull(client)) {
            client = new Client(host, port);
            clientMap.put(key, client);
        }
        return client;
    }


    public synchronized void init() {
        if (!isConnect.get()) {
            try {
                this.clientHandler = new ClientHandler();
                this.connect(host, port);
                isConnect.set(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void connect(String host, int port) throws InterruptedException {
        EventLoopGroup workGroup = new NioEventLoopGroup();
        Bootstrap bootstrap = new Bootstrap();
        bootstrap.group(workGroup)
                .channel(NioSocketChannel.class)
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 3000)
                .option(ChannelOption.SO_RCVBUF, 1024 * 32)
                .option(ChannelOption.SO_SNDBUF, 1024 * 32)
                .handler(new ChannelInitializer<SocketChannel>() {
                    protected void initChannel(SocketChannel socketChannel) throws Exception {
                        socketChannel.pipeline().addLast(new RpcEncoder(new JSONSerializer()));
                        socketChannel.pipeline().addLast(new RpcDecoder(new JSONSerializer()));

                        socketChannel.pipeline().addLast(clientHandler);
                    }
                });

        ChannelFuture channelFuture = bootstrap.connect(host, port).syncUninterruptibly();
        this.channel = channelFuture.channel();
        this.channel.closeFuture().sync();
    }

    public String getHost() {
        return host;
    }

    public int getPort() {
        return port;
    }

    /**
     * 发送消息
     *
     * @param cmd    处理消息的命令
     * @param object 请求参数
     */
    public void sendMessage(String cmd, Object object) {
        if (Objects.isNull(this.channel)) {
            throw new RuntimeException("netty未启动成功");
        }
        this.channel.writeAndFlush(MessageBuilder.getInstance(MessageType.REQUEST).cmd(cmd).body(object).build());
    }


    public Message sendMessageSync(String cmd, Object object) throws ExecutionException, InterruptedException {
        if (Objects.isNull(this.channel)) {
            throw new RuntimeException("netty未启动成功");
        }
        this.clientHandler.setParam(MessageBuilder.getInstance(MessageType.REQUEST).cmd(cmd).body(object).build());
        return executorService.submit(this.clientHandler).get();
    }


}
