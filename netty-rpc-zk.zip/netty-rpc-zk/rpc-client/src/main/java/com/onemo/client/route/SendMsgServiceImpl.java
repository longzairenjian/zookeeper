package com.onemo.client.route;

import com.alibaba.fastjson.JSONObject;
import com.onemo.client.core.Client;
import com.onemo.client.core.ClientTask;
import com.onemo.client.core.ClientTaskHelper;
import com.onemo.client.core.Metrics;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class SendMsgServiceImpl implements SendMsgService {

    @Resource
    private LoadBalanceStrategy loadBalance;

    @Override
    public void routeSendMsg(String cmd, Object msg) {
        //负载均衡  获取响应时间最短的服务端ip
        String route = loadBalance.route();
        ClientTask clientTask;
        if (StringUtils.isEmpty(route)) {
            clientTask = ClientTaskHelper.getClientTask();
        } else {
            clientTask = ClientTaskHelper.get(route);
        }
        sendMsg(clientTask.getClient(), cmd, msg+"=====>route");
    }

    @Override
    public void sendAll(String cmd, Object msg) {
        Map<String, ClientTask> clientTaskMap = ClientTaskHelper.getClientTaskMap();
        clientTaskMap.forEach((key, value) -> sendMsg(value.getClient(), cmd, msg));
    }

    @Override
    public void sendMsg(Client client, String cmd, Object msg) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", msg);
        jsonObject.put("metrics", new Metrics(client.getHost(), client.getPort()));
        client.sendMessage(cmd, jsonObject);
    }
}
