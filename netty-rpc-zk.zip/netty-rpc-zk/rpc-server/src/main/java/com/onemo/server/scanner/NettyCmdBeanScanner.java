package com.onemo.server.scanner;

import com.onemo.common.annotation.Cmd;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Objects;

/**
 * 实现BeanPostProcessor 接口 在bean初始化之后加载所有的bean
 * 然后找到所有带有cmd注解标识的方法 存入InvokeTable中 后期直接
 * 从中获取方法调用
 */
@Component
public class NettyCmdBeanScanner implements BeanPostProcessor {

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> clazz = bean.getClass();
        Method[] methods = clazz.getMethods();
        for (Method method : methods) {
            Cmd cmd = method.getAnnotation(Cmd.class);
            if (Objects.nonNull(cmd)) {
                InvokeTable.addInvoke(cmd.value(), Invoker.create(bean, method));
            }
        }
        return bean;
    }
}
