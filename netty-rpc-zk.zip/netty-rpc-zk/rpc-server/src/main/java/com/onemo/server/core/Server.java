package com.onemo.server.core;

import com.onemo.common.serialize.JSONSerializer;
import com.onemo.common.serialize.RpcDecoder;
import com.onemo.common.serialize.RpcEncoder;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;

import java.util.Objects;

public class Server {

    public static void startServer(String[] args) throws InterruptedException {
        int port = 8888;
        if (Objects.nonNull(args) && args.length > 0) {
            port = Integer.parseInt(args[0]);
        }
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workGroup = new NioEventLoopGroup();

        ServerBootstrap serverBootstrap = new ServerBootstrap();
        //NIO SERVER 基础配置
        serverBootstrap.group(bossGroup, workGroup);
        serverBootstrap.channel(NioServerSocketChannel.class);
        serverBootstrap.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 3000);
        serverBootstrap.option(ChannelOption.SO_BACKLOG, 1024);
        serverBootstrap.childOption(ChannelOption.TCP_NODELAY, true);
        serverBootstrap.childOption(ChannelOption.SO_RCVBUF, 1024 * 32);
        serverBootstrap.childOption(ChannelOption.SO_SNDBUF, 1024 * 32);
        serverBootstrap.childHandler(new ChannelInitializer<SocketChannel>() {
            protected void initChannel(SocketChannel socketChannel) {
                socketChannel.pipeline().addLast(new RpcEncoder(new JSONSerializer()));
                socketChannel.pipeline().addLast(new RpcDecoder(new JSONSerializer()));
                socketChannel.pipeline().addLast(new ServerHandler());
            }
        });//设置缓冲区大小
        ChannelFuture sync = serverBootstrap.bind(port).sync();
        sync.channel().closeFuture().sync();
        //释放资源
        bossGroup.shutdownGracefully();
        workGroup.shutdownGracefully();
    }

}
