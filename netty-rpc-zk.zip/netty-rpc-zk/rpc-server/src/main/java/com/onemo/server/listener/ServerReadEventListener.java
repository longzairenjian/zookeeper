package com.onemo.server.listener;

import com.onemo.server.core.Server;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;

public class ServerReadEventListener implements ApplicationListener<ApplicationReadyEvent> {

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        try {
            Server.startServer(applicationReadyEvent.getArgs());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("netty server 已经启动了");
    }
}
