package com.onemo.server.scanner;

import java.lang.reflect.Method;

public class Invoker {

    /**
     * 目标对象
     */
    private Object target;
    /**
     * 需要执行的方法
     */
    private Method method;

    public Invoker() {
    }

    public Invoker(Object target, Method method) {
        this.target = target;
        this.method = method;
    }

    public static Invoker create(Object target, Method method) {
        return new Invoker(target, method);
    }


    public Object invoke(Object... params) {
        try {
            return this.method.invoke(target, params);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Object getTarget() {
        return target;
    }

    public void setTarget(Object target) {
        this.target = target;
    }

    public Method getMethod() {
        return method;
    }

    public void setMethod(Method method) {
        this.method = method;
    }
}
