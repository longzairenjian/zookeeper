package com.onemo.server.runner;

import com.onemo.common.zk.ProviderConstant;
import com.onemo.common.zk.ZkTemplate;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Objects;

@Component
public class ZkServerRunner implements ApplicationRunner {

    @Resource
    private ZkTemplate zkTemplate;

    private static final String LOCALHOST = "127.0.0.1";


    @Override
    public void run(ApplicationArguments applicationArguments) throws Exception {
        int port = ProviderConstant.DEFAULT_PORT;
        String[] args = applicationArguments.getSourceArgs();
        if (Objects.nonNull(args) && args.length > 0) {
            port = Integer.parseInt(args[0]);
        }
        //向zk注册服务节点
        if (!zkTemplate.checkExists(ProviderConstant.PROVIDER_PATH)) {
            //不存在则创建节点
            zkTemplate.createForPersistent(ProviderConstant.PROVIDER_PATH, null);
        }
        //创建临时节点
        zkTemplate.createForEphemeral(ProviderConstant.PROVIDER_PATH + "/" + LOCALHOST + ":" + port, null);
    }
}
