package com.onemo.server.core;

import com.onemo.common.Message;
import com.onemo.common.enumtype.MessageType;
import com.onemo.common.enumtype.ResultType;
import com.onemo.server.scanner.InvokeTable;
import com.onemo.server.scanner.Invoker;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

import java.util.Objects;


public class ServerHandler extends ChannelInboundHandlerAdapter {

    /**
     * 通道激活方法
     */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.err.println("server channel active!");
    }

    /**
     * 读写数据的核心方法
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Message message = (Message) msg;
        String cmd = message.getCmd();
        Invoker invoke = InvokeTable.getInvoke(cmd);
        if (Objects.nonNull(invoke)) {
            Object result = invoke.invoke(message.getBody());
            message.setResultType(ResultType.SUCCESS);
            message.setBody(result);
        } else {
            message.setResultType(ResultType.FAILURE);
            message.setBody("404");
        }
        message.setMessageType(MessageType.RESPONSE);
        ctx.writeAndFlush(message);
    }


    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        ctx.fireExceptionCaught(cause);
    }
}
