package com.onemo.server.scanner;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class InvokeTable {

    private static final Map<String, Invoker> invokeMap = new ConcurrentHashMap<>();

    public static void addInvoke(String cmd, Invoker invoker) {
        invokeMap.put(cmd, invoker);
    }

    public static Invoker getInvoke(String cmd) {
        return invokeMap.get(cmd);
    }
}
