package com.onemo.server.service;

import com.onemo.common.annotation.Cmd;
import org.springframework.stereotype.Service;

@Service
public class ListenerCmdService {


    /**
     * 监听aa命令
     *
     * @param object 消息
     */
    @Cmd("aa")
    public void listenerMsg(Object object) {
        System.out.println(object);
    }

    @Cmd("cc")
    public Object listenerMsg3(Object object) {
        System.out.println(object);
        return object;
    }

    @Cmd("bb")
    public Object listenerMsg2(Object object) {
        System.out.println(object.toString());
        return "SUCCESS";
    }
}
