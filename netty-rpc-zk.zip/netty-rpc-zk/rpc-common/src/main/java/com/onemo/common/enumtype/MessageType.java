package com.onemo.common.enumtype;

public enum MessageType {
    REQUEST,RESPONSE
}
