package com.onemo.common;

import com.onemo.common.enumtype.MessageType;
import com.onemo.common.enumtype.ResultType;

/**
 * rpc通信统一请求参数
 */
public class Message {

    /**
     * 请求编码
     */
    private String rpcCode;

    /**
     * 消息类型
     */
    private MessageType messageType;

    /**
     * 结果类型
     */
    private ResultType resultType;

    /**
     * 执行命令
     */
    private String cmd;

    /**
     * 请求数据
     */
    private Object body;

    public String getRpcCode() {
        return rpcCode;
    }

    public void setRpcCode(String rpcCode) {
        this.rpcCode = rpcCode;
    }

    public MessageType getMessageType() {
        return messageType;
    }

    public void setMessageType(MessageType messageType) {
        this.messageType = messageType;
    }

    public ResultType getResultType() {
        return resultType;
    }

    public void setResultType(ResultType resultType) {
        this.resultType = resultType;
    }

    public String getCmd() {
        return cmd;
    }

    public void setCmd(String cmd) {
        this.cmd = cmd;
    }

    public Object getBody() {
        return body;
    }

    public void setBody(Object body) {
        this.body = body;
    }
}
