package com.onemo.common.serialize;

import com.onemo.common.Message;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;

public class RpcEncoder extends MessageToByteEncoder<Message> {


    private final Serializer serializer;


    public RpcEncoder(Serializer serializer) {
        this.serializer = serializer;
    }

    @Override
    protected void encode(ChannelHandlerContext channelHandlerContext, Message message, ByteBuf byteBuf) throws Exception {
        byte[] bytes = serializer.serialize(message);
        byteBuf.writeInt(bytes.length);
        byteBuf.writeBytes(bytes);
    }
}