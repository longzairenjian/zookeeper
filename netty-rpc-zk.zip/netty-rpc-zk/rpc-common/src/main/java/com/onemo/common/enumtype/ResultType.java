package com.onemo.common.enumtype;

public enum ResultType {
    SUCCESS,FAILURE,SYS_ERROR
}
