package com.onemo.common.zk;

import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheListener;
import org.apache.zookeeper.CreateMode;
import org.springframework.util.StringUtils;

import java.util.List;

public class ZkTemplate {

    /**
     * 操作zk客户端
     */
    private final CuratorFramework zkClient;

    public ZkTemplate(CuratorFramework zkClient) {
        this.zkClient = zkClient;
    }


    /**
     * 创建一个空节持久点
     *
     * @param path 节点路径
     */
    public void createForPersistent(String path, byte[] data) {
        create(CreateMode.PERSISTENT, path, data);
    }

    /**
     * 创建一个空节持久点
     *
     * @param path 节点路径
     */
    public void createForEphemeral(String path, byte[] data) {
        create(CreateMode.EPHEMERAL, path, data);
    }


    /**
     * 创建一个节点
     *
     * @param createMode 节点类型
     * @param path       节点路径
     * @param data       节点数据
     */
    public void create(CreateMode createMode, String path, byte[] data) {

        try {
            zkClient.create().creatingParentsIfNeeded().withMode(createMode).forPath(formatPath(path), data);
        } catch (Exception e) {
            throw new RuntimeException("create zk node fail", e);
        }
    }


    public boolean checkExists(String path) {
        try {
            return zkClient.checkExists().forPath(formatPath(path)) != null;
        } catch (Exception e) {
            throw new RuntimeException("checkExists zk node path fail", e);
        }
    }

    /**
     * 获取子节点列表
     *
     * @param path 子节点路径
     * @return 子节点列表
     */
    public List<String> getChildren(String path) {
        try {
            return zkClient.getChildren().forPath(formatPath(path));
        } catch (Exception e) {
            throw new RuntimeException("zk getChildren fail", e);
        }
    }

    /**
     * 获取节点数据
     * @param path 节点路径
     * @return 数据字节
     */
    public byte[] getData(String path) {
        try {
            return zkClient.getData().forPath(path);
        } catch (Exception e) {
            throw new RuntimeException("zk getData fail", e);
        }
    }


    /**
     * 监听节点
     *
     * @param path     节点路径
     * @param listener 监听接口实现
     */
    public void watch(String path, PathChildrenCacheListener listener) {
        PathChildrenCache pathChildrenCache = new PathChildrenCache(this.zkClient, path, true);
        pathChildrenCache.getListenable().addListener(listener);
        try {
            pathChildrenCache.start(PathChildrenCache.StartMode.POST_INITIALIZED_EVENT);
        } catch (Exception e) {
            throw new RuntimeException("watch node fail", e);
        }
    }


    /**
     * 格式化路径 路径必须以/开头
     *
     * @param path 未格式化的路径
     * @return 格式化后的路径
     */
    private static String formatPath(String path) {
        if (!StringUtils.startsWithIgnoreCase(path, "/")) {
            path = "/" + path;
        }
        return path;
    }
}
