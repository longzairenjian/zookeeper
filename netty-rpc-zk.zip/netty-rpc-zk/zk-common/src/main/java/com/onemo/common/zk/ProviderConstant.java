package com.onemo.common.zk;

public class ProviderConstant {

    public static final String PROVIDER_PATH = "/provider";

    public static final Integer DEFAULT_PORT = 8888;
}
