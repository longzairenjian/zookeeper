package com.onemo.common.zk;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ZkConfiguration {

    @Bean
    public ZkTemplate zkTemplate(ZkProperties zkProperties) {
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(1000, 3);
        CuratorFramework client = CuratorFrameworkFactory.builder()
                //server地址
                .connectString(zkProperties.getUrl())
                // 会话超时时间
                .sessionTimeoutMs(zkProperties.getSessionTimeOut())
                // 连接超时时间
                .connectionTimeoutMs(zkProperties.getConnectTimeOut())
                // 重试策略
                .retryPolicy(retryPolicy)
                //工作空间
                .namespace(zkProperties.getNamespace())
                .build();
        client.start();
        return new ZkTemplate(client);
    }
}
