package com.onemo.datasource;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@Service
public class ConnectionService {

    @Resource
    private DataSourceConfiguration dataSourceConfiguration;

    public void connect() {
        try {
            DataSource dataSource = dataSourceConfiguration.getDataSource();
            PreparedStatement preparedStatement = dataSource.getConnection().prepareStatement("select * from tb_resume");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                System.out.println("返回结果:" + resultSet.getString(3));
            }
        } catch (Exception e) {
            throw new RuntimeException("connect fail",e);
        }
    }
}
