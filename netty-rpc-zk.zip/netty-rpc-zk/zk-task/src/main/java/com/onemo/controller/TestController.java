package com.onemo.controller;

import com.onemo.datasource.ConnectionService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class TestController {


    @Resource
    private ConnectionService connectionService;

    @GetMapping("/")
    public String index() {
        return "<h1>HELLO TEST</h1>";
    }


    @GetMapping("test")
    public void test(){
        connectionService.connect();
    }
}
