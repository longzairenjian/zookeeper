package com.onemo.datasource;

import com.alibaba.druid.pool.DruidDataSource;
import com.onemo.common.zk.ZkTemplate;
import org.apache.curator.framework.recipes.cache.PathChildrenCacheEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Configuration
public class DataSourceConfiguration {

    @Resource
    private ZkTemplate zkTemplate;

    private static final String CONFIG = "/config";

    private DruidDataSource dataSource;

    /**
     * 启动的时候初始化datasource
     * 病监听配置子节点变更
     */
    @PostConstruct
    public void init() {
        this.dataSource = createDataSource();
        //监听配置节点
        watchConfig();
    }


    public DruidDataSource getDataSource() {
        if (Objects.isNull(dataSource)) {
            dataSource = createDataSource();
        }
        return dataSource;
    }

    private DruidDataSource createDataSource() {
        DruidDataSource druidDataSource = new DruidDataSource();
        Map<String, String> configMap = this.getConfigMap();
        druidDataSource.setUrl(configMap.get("url"));
        druidDataSource.setPassword(configMap.get("password"));
        druidDataSource.setDriverClassName(configMap.get("driverClassName"));
        druidDataSource.setUsername(configMap.get("userName"));
        return druidDataSource;
    }


    private Map<String, String> getConfigMap() {
        List<String> children = zkTemplate.getChildren(CONFIG);
        if (CollectionUtils.isEmpty(children)) {
            throw new RuntimeException("mysql config info is not");
        }
        Map<String, String> configMap = new HashMap<>();
        children.forEach(f -> configMap.put(f, new String(zkTemplate.getData(CONFIG + "/" + f), StandardCharsets.UTF_8)));
        return configMap;
    }

    private void watchConfig() {
        zkTemplate.watch(CONFIG, (curatorFramework, pathChildrenCacheEvent) -> {
            if (PathChildrenCacheEvent.Type.CHILD_UPDATED.equals(pathChildrenCacheEvent.getType())) {
                //重新生成新的数据源
                DruidDataSource dataSource = createDataSource();
                this.dataSource.close();
                this.dataSource = dataSource;
            }
        });
    }

}
