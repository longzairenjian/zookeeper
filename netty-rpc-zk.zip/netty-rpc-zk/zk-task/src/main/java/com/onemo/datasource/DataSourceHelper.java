package com.onemo.datasource;

import javax.sql.DataSource;

public class DataSourceHelper {

    private static DataSource dataSource;

    static {

    }



}
